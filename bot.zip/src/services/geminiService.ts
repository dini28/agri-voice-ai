import { API_CONFIG } from '@/config/api';

export interface GeminiResponse {
  success: boolean;
  data?: string;
  error?: string;
  usage?: {
    promptTokens: number;
    responseTokens: number;
    totalTokens: number;
  };
}

export class GeminiService {
  private apiKey: string;
  private baseUrl = API_CONFIG.GEMINI_BASE_URL;
  private model = API_CONFIG.GEMINI_MODEL;
  private requestCount = 0;
  private lastRequestTime = 0;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || API_CONFIG.GEMINI_API_KEY;
    if (!this.apiKey || this.apiKey === 'your_gemini_api_key_here') {
      throw new Error('Gemini API key is required. Please set VITE_GEMINI_API_KEY in your environment variables.');
    }
  }

  private validateApiKey(): boolean {
    return !!(this.apiKey && this.apiKey.length > 20 && this.apiKey !== 'your_gemini_api_key_here');
  }

  private async rateLimitCheck(): Promise<void> {
    const now = Date.now();
    const timeDiff = now - this.lastRequestTime;
    
    // Simple rate limiting: max 60 requests per minute
    if (timeDiff < 60000 && this.requestCount >= 60) {
      throw new Error('Rate limit exceeded. Please wait a moment before making another request.');
    }
    
    if (timeDiff >= 60000) {
      this.requestCount = 0;
    }
    
    this.requestCount++;
    this.lastRequestTime = now;
  }

  private getSystemPrompt(language: string): string {
    const prompts: Record<string, string> = {
      hi: `आप AgriBot हैं, एक मित्रवत और जानकार कृषि क्षेत्र के लिए AI सहायक हैं। आप सरल भाषा में बात करते हैं। तकनीकी शब्दजाल से बचें जब तक कि न पूछा जाए। फसलों, कीटों, उर्वरकों, और सरकारी योजनाओं पर व्यावहारिक सलाह दें। भारतीय कृषि पद्धतियों के अनुकूल उत्तर दें।`,
      en: `You are AgriBot, a friendly and knowledgeable AI assistant for the agriculture sector. Speak in simple language. Avoid jargon unless asked. Provide region-specific, practical advice on crops, pests, fertilizers, and government schemes for Indian farmers.`,
      ta: `நீங்கள் AgriBot, விவசாயத் துறைக்கான நட்பான மற்றும் அறிவுள்ள AI உதவியாளர். எளிய மொழியில் பேசுங்கள். இந்திய விவசாயிகளுக்கு பயிர்கள், பூச்சிகள், உரங்கள் மற்றும் அரசு திட்டங்கள் குறித்து நடைமுறை ஆலோசனை வழங்குங்கள்.`,
      te: `మీరు AgriBot, వ్యవసాయ రంగానికి స్నేహపూర్వక మరియు జ్ఞానవంతమైన AI సహాయకుడు. సులభమైన భాషలో మాట్లాడండి. భారతీయ రైతులకు పంటలు, కీటకాలు, ఎరువులు మరియు ప్రభుత్వ పథకాలపై ఆచరణాత్మక సలహా ఇవ్వండి.`,
      kn: `ನೀವು AgriBot, ಕೃಷಿ ಕ್ಷೇತ್ರಕ್ಕಾಗಿ ಸ್ನೇಹಪರ ಮತ್ತು ಜ್ಞಾನವುಳ್ळ AI ಸಹಾಯಕರಾಗಿದ್ದೀರಿ. ಸರಳ ಭಾಷೆಯಲ್ಲಿ ಮಾತನಾಡಿ. ಭಾರತೀಯ ರೈತರಿಗೆ ಬೆಳೆಗಳು, ಕೀಟಗಳು, ರಸಗೊಬ್ಬರಗಳು ಮತ್ತು ಸರ್ಕಾರಿ ಯೋಜನೆಗಳ ಬಗ್ಗೆ ಪ್ರಾಯೋಗಿಕ ಸಲಹೆ ನೀಡಿ.`,
      mr: `तुम्ही AgriBot आहात, कृषी क्षेत्रासाठी मैत्रीपूर्ण आणि ज्ञानी AI सहाय्यक. सोप्या भाषेत बोला. भारतीय शेतकऱ्यांना पिके, किडे, खते आणि सरकारी योजनांबद्दल व्यावहारिक सल्ला द्या.`
    };

    return prompts[language] || prompts.en;
  }

  async sendMessage(userMessage: string, language: string = 'en'): Promise<GeminiResponse> {
    try {
      // Validate API key
      if (!this.validateApiKey()) {
        return {
          success: false,
          error: 'Invalid or missing API key. Please check your configuration.'
        };
      }

      // Rate limiting check
      await this.rateLimitCheck();

      const systemPrompt = this.getSystemPrompt(language);
      const languageNames: Record<string, string> = {
        hi: 'Hindi',
        en: 'English',
        ta: 'Tamil',
        te: 'Telugu',
        kn: 'Kannada',
        mr: 'Marathi'
      };

      // Enhanced prompt with better context
      const fullPrompt = `${systemPrompt}

Context: You are AgriBot, an expert agricultural assistant. Provide accurate, practical, and actionable advice based on Indian farming practices and conditions.

User Question: ${userMessage}

Instructions:
- Respond in ${languageNames[language] || 'English'} language
- Provide specific, actionable advice
- Include relevant tips and precautions
- Keep responses concise but comprehensive
- Use simple language that farmers can easily understand
- Include regional considerations when relevant`;

      const requestBody = {
        contents: [{
          parts: [{ text: fullPrompt }]
        }],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.8,
          maxOutputTokens: 1500,
          candidateCount: 1,
          stopSequences: []
        },
        safetySettings: [
          {
            category: 'HARM_CATEGORY_HARASSMENT',
            threshold: 'BLOCK_MEDIUM_AND_ABOVE'
          },
          {
            category: 'HARM_CATEGORY_HATE_SPEECH',
            threshold: 'BLOCK_MEDIUM_AND_ABOVE'
          },
          {
            category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
            threshold: 'BLOCK_MEDIUM_AND_ABOVE'
          },
          {
            category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
            threshold: 'BLOCK_MEDIUM_AND_ABOVE'
          }
        ]
      };

      const response = await fetch(`${this.baseUrl}/models/${this.model}:generateContent?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        const errorMessage = errorData?.error?.message || response.statusText;
        
        // Handle specific error cases
        if (response.status === 400) {
          return {
            success: false,
            error: 'Invalid request. Please check your question and try again.'
          };
        } else if (response.status === 401) {
          return {
            success: false,
            error: 'Authentication failed. Please check your API key.'
          };
        } else if (response.status === 429) {
          return {
            success: false,
            error: 'Too many requests. Please wait a moment and try again.'
          };
        } else if (response.status >= 500) {
          return {
            success: false,
            error: 'Server error. Please try again later.'
          };
        }

        return {
          success: false,
          error: `API Error: ${response.status} - ${errorMessage}`
        };
      }

      const data = await response.json();

      // Check for safety issues
      if (data.candidates && data.candidates.length > 0) {
        const candidate = data.candidates[0];
        
        if (candidate.finishReason === 'SAFETY') {
          return {
            success: false,
            error: 'Response blocked due to safety concerns. Please rephrase your question.'
          };
        }

        const content = candidate.content?.parts?.[0]?.text;
        if (content) {
          return {
            success: true,
            data: content.trim(),
            usage: {
              promptTokens: data.usageMetadata?.promptTokenCount || 0,
              responseTokens: data.usageMetadata?.candidatesTokenCount || 0,
              totalTokens: data.usageMetadata?.totalTokenCount || 0
            }
          };
        }
      }

      return {
        success: false,
        error: 'No valid response received from the AI service.'
      };

    } catch (error) {
      console.error('Error calling Gemini API:', error);
      
      // Handle network errors
      if (error instanceof TypeError && error.message.includes('fetch')) {
        return {
          success: false,
          error: 'Network error. Please check your internet connection and try again.'
        };
      }

      return {
        success: false,
        error: 'An unexpected error occurred. Please try again.'
      };
    }
  }

  // Legacy method for backward compatibility
  async sendMessageLegacy(userMessage: string, language: string = 'en'): Promise<string> {
    const response = await this.sendMessage(userMessage, language);
    
    if (response.success && response.data) {
      return response.data;
    }

    // Return localized error messages
    const errorMessages: Record<string, string> = {
      hi: 'क्षमा करें, मुझे कुछ तकनीकी समस्या हो रही है। कृपया फिर से कोशिश करें।',
      en: 'Sorry, I\'m experiencing some technical issues. Please try again.',
      ta: 'மன்னிக்கவும், எனக்கு சில தொழில்நுட்ப சிக்கல்கள் உள்ளன. மீண்டும் முயற்சிக்கவும்.',
      te: 'క్షమించండి, నాకు కొన్ని సాంకేతిక సమస్యలు ఉన్నాయి. దయచేసి మళ్లీ ప్రయత్నించండి.',
      kn: 'ಕ್ಷಮಿಸಿ, ನನಗೆ ಕೆಲವು ತಾಂತ್ರಿಕ ಸಮಸ್ಯೆಗಳಿವೆ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
      mr: 'माफ करा, मला काही तांत्रिक समस्या येत आहेत. कृपया पुन्हा प्रयत्न करा.'
    };

    return errorMessages[language] || errorMessages.en;
  }

  async translateResponse(text: string, targetLanguage: string): Promise<string> {
    if (targetLanguage === 'en') return text;

    const languageNames: Record<string, string> = {
      hi: 'Hindi',
      ta: 'Tamil',
      te: 'Telugu',
      kn: 'Kannada',
      mr: 'Marathi'
    };

    const translatePrompt = `Translate the following agricultural advice into ${languageNames[targetLanguage]} language, maintaining the technical accuracy and helpful tone: ${text}`;

    return await this.sendMessage(translatePrompt, targetLanguage);
  }
}

// Agricultural knowledge base prompts
export const agriculturalPrompts = {
  cropGuidance: {
    hi: "फसल की खेती के बारे में मार्गदर्शन चाहिए",
    en: "Need guidance on crop cultivation",
    ta: "பயிர் சாகுபடி வழிகாட்டுதல் தேவை",
    te: "పంట సాగు మార్గదర్శకత్వం కావాలి",
    kn: "ಬೆಳೆ ಕೃಷಿ ಮಾರ್ಗದರ್ಶನ ಬೇಕು",
    mr: "पीक लागवड मार्गदर्शन हवे"
  },
  pestControl: {
    hi: "कीट नियंत्रण की जानकारी चाहिए",
    en: "Need information on pest control",
    ta: "பூச்சி கட்டுப்பாடு தகவல் தேவை",
    te: "కీటకాల నియంత్రణ సమాచారం కావాలి",
    kn: "ಕೀಟ ನಿಯಂತ್ರಣ ಮಾಹಿತಿ ಬೇಕು",
    mr: "किड नियंत्रण माहिती हवी"
  },
  fertilizer: {
    hi: "उर्वरक की सलाह चाहिए",
    en: "Need fertilizer advice",
    ta: "உரம் ஆலோசனை தேவை",
    te: "ఎరువుల సలహా కావాలి",
    kn: "ರಸಗೊಬ್ಬರ ಸಲಹೆ ಬೇಕು",
    mr: "खत सल्ला हवा"
  },
  weather: {
    hi: "मौसम संबंधी सलाह चाहिए",
    en: "Need weather-related advice",
    ta: "வானிலை தொடர்பான ஆலோசனை தேவை",
    te: "వాతావరణ సంబంధిత సలహా కావాలి",
    kn: "ಹವಾಮಾನ ಸಂಬಂಧಿತ ಸಲಹೆ ಬೇಕು",
    mr: "हवामान संबंधी सल्ला हवा"
  },
  schemes: {
    hi: "सरकारी योजनाओं की जानकारी चाहिए",
    en: "Need information on government schemes",
    ta: "அரசு திட்டங்கள் பற்றிய தகவல் தேவை",
    te: "ప్రభుత్వ పథకాల సమాచారం కావాలి",
    kn: "ಸರ್ಕಾರಿ ಯೋಜನೆಗಳ ಮಾಹಿತಿ ಬೇಕು",
    mr: "सरकारी योजनांची माहिती हवी"
  }
};

// Export types for better type safety
export interface ApiResponse {
  candidates?: Array<{
    content?: {
      parts?: Array<{ text?: string }>;
    };
  }>;
  error?: {
    message: string;
    code: number;
  };
}

export interface GeminiConfig {
  temperature?: number;
  topK?: number;
  topP?: number;
  maxOutputTokens?: number;
}