// API Configuration
export const API_CONFIG = {
  GEMINI_API_KEY: import.meta.env.VITE_GEMINI_API_KEY || '',
  GEMINI_BASE_URL: 'https://generativelanguage.googleapis.com/v1beta',
  GEMINI_MODEL: 'gemini-pro',
} as const;

// Helper function to check if API key is configured
export const isApiKeyConfigured = (): boolean => {
  return !!API_CONFIG.GEMINI_API_KEY && API_CONFIG.GEMINI_API_KEY !== 'your_gemini_api_key_here';
};

// Helper function to get API key with validation
export const getApiKey = (): string => {
  if (!isApiKeyConfigured()) {
    throw new Error('Gemini API key is not configured. Please set VITE_GEMINI_API_KEY in your environment variables.');
  }
  return API_CONFIG.GEMINI_API_KEY;
};
