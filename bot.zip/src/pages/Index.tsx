// pages/Index.tsx - Home page
import React from 'react';
import { HeroSection } from '@/components/HeroSection';
import FeaturesSection from '@/components/sections/FeaturesSection';
import StatsSection from '@/components/sections/StatsSection';
import HowItWorksSection from '@/components/sections/HowItWorksSection';
import ApiStatusSection from '@/components/sections/ApiStatusSection';
import CtaSection from '@/components/sections/CtaSection';

const Index: React.FC = () => {
  return (
    <div className="bg-gradient-sky min-h-screen">
      <HeroSection />
      <ApiStatusSection />
      <FeaturesSection />
      <StatsSection />
      <HowItWorksSection />
      <CtaSection />
    </div>
  );
};

export default Index;