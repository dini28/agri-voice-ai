import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  RefreshCw,
  Key,
  Zap,
  Globe
} from 'lucide-react';
import { GeminiService } from '@/services/geminiService';
import { isApiKeyConfigured } from '@/config/api';

interface ApiStatus {
  isConfigured: boolean;
  isWorking: boolean;
  lastTested: Date | null;
  error: string | null;
  responseTime: number | null;
}

const ApiStatusSection: React.FC = () => {
  const [apiStatus, setApiStatus] = useState<ApiStatus>({
    isConfigured: false,
    isWorking: false,
    lastTested: null,
    error: null,
    responseTime: null
  });
  const [isTesting, setIsTesting] = useState(false);

  useEffect(() => {
    checkApiStatus();
  }, []);

  const checkApiStatus = async () => {
    setIsTesting(true);
    const startTime = Date.now();
    
    try {
      const isConfigured = isApiKeyConfigured();
      
      if (!isConfigured) {
        setApiStatus({
          isConfigured: false,
          isWorking: false,
          lastTested: new Date(),
          error: 'API key not configured',
          responseTime: null
        });
        return;
      }

      // Test the API with a simple query
      const geminiService = new GeminiService();
      const response = await geminiService.sendMessage('Hello, are you working?', 'en');
      
      const endTime = Date.now();
      const responseTime = endTime - startTime;

      setApiStatus({
        isConfigured: true,
        isWorking: response.success,
        lastTested: new Date(),
        error: response.error || null,
        responseTime: response.success ? responseTime : null
      });

    } catch (error) {
      const endTime = Date.now();
      setApiStatus({
        isConfigured: true,
        isWorking: false,
        lastTested: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error',
        responseTime: null
      });
    } finally {
      setIsTesting(false);
    }
  };

  const getStatusIcon = () => {
    if (isTesting) {
      return <RefreshCw className="h-6 w-6 text-blue-500 animate-spin" />;
    }
    
    if (!apiStatus.isConfigured) {
      return <XCircle className="h-6 w-6 text-red-500" />;
    }
    
    if (apiStatus.isWorking) {
      return <CheckCircle className="h-6 w-6 text-green-500" />;
    }
    
    return <AlertTriangle className="h-6 w-6 text-yellow-500" />;
  };

  const getStatusColor = () => {
    if (!apiStatus.isConfigured) return 'bg-red-100 text-red-700 border-red-200';
    if (apiStatus.isWorking) return 'bg-green-100 text-green-700 border-green-200';
    return 'bg-yellow-100 text-yellow-700 border-yellow-200';
  };

  const getStatusText = () => {
    if (isTesting) return 'Testing API...';
    if (!apiStatus.isConfigured) return 'API Key Not Configured';
    if (apiStatus.isWorking) return 'API Working Perfectly';
    return 'API Issues Detected';
  };

  return (
    <section className="py-12 bg-gradient-to-r from-blue-50 to-indigo-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
          <CardContent className="p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center">
                  <Key className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Gemini API Status</h3>
                  <p className="text-gray-600">Real-time API connectivity and performance monitoring</p>
                </div>
              </div>
              
              <Button
                onClick={checkApiStatus}
                disabled={isTesting}
                variant="outline"
                className="flex items-center gap-2"
              >
                <RefreshCw className={`h-4 w-4 ${isTesting ? 'animate-spin' : ''}`} />
                {isTesting ? 'Testing...' : 'Test API'}
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Status */}
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  {getStatusIcon()}
                  <Badge className={getStatusColor()}>
                    {getStatusText()}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">
                  {apiStatus.lastTested && `Last tested: ${apiStatus.lastTested.toLocaleTimeString()}`}
                </p>
              </div>

              {/* Response Time */}
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Zap className="h-6 w-6 text-purple-500" />
                  <span className="font-semibold text-gray-900">Response Time</span>
                </div>
                <p className="text-2xl font-bold text-purple-600">
                  {apiStatus.responseTime ? `${apiStatus.responseTime}ms` : 'N/A'}
                </p>
              </div>

              {/* Language Support */}
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Globe className="h-6 w-6 text-green-500" />
                  <span className="font-semibold text-gray-900">Languages</span>
                </div>
                <p className="text-2xl font-bold text-green-600">6</p>
                <p className="text-sm text-gray-600">Supported languages</p>
              </div>
            </div>

            {/* Error Message */}
            {apiStatus.error && (
              <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                  <span className="font-semibold text-red-700">Error Details:</span>
                </div>
                <p className="text-red-600 text-sm">{apiStatus.error}</p>
              </div>
            )}

            {/* Setup Instructions */}
            {!apiStatus.isConfigured && (
              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-semibold text-blue-700 mb-2">Setup Instructions:</h4>
                <ol className="text-blue-600 text-sm space-y-1 list-decimal list-inside">
                  <li>Get your Gemini API key from Google AI Studio</li>
                  <li>Create a <code className="bg-blue-100 px-1 rounded">.env</code> file in your project root</li>
                  <li>Add <code className="bg-blue-100 px-1 rounded">VITE_GEMINI_API_KEY=your_api_key_here</code></li>
                  <li>Restart your development server</li>
                </ol>
              </div>
            )}

            {/* Success Message */}
            {apiStatus.isWorking && (
              <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span className="font-semibold text-green-700">API is working perfectly!</span>
                </div>
                <p className="text-green-600 text-sm">
                  AgriBot is ready to help farmers with their agricultural queries. 
                  The API is responding quickly and accurately.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default ApiStatusSection;
