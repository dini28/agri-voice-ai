# Gemini API Setup Guide for AgriBot

This guide will help you set up the Gemini API for your AgriBot application to enable AI-powered agricultural assistance.

## Prerequisites

- Google account
- Node.js and npm installed
- Basic understanding of environment variables

## Step 1: Get Your Gemini API Key

1. **Visit Google AI Studio**
   - Go to [https://makersuite.google.com/app/apikey](https://makersuite.google.com/app/apikey)

2. **Sign in with your Google account**
   - Use the same Google account you want to use for the API

3. **Create a new API key**
   - Click "Create API Key"
   - Choose "Create API key in new project" or select an existing project
   - Copy the generated API key (it will look like: `AIzaSyB...`)

## Step 2: Configure Environment Variables

1. **Create a `.env` file** in your project root directory:
   ```bash
   touch .env
   ```

2. **Add your API key to the `.env` file**:
   ```env
   VITE_GEMINI_API_KEY=your_actual_api_key_here
   ```

   **Important:** Replace `your_actual_api_key_here` with the API key you copied from Google AI Studio.

3. **Add `.env` to your `.gitignore`** (if not already present):
   ```gitignore
   .env
   .env.local
   .env.production
   ```

## Step 3: Verify the Setup

1. **Restart your development server**:
   ```bash
   npm run dev
   # or
   yarn dev
   ```

2. **Check the API status**:
   - Open your application in the browser
   - Navigate to the home page
   - Look for the "Gemini API Status" section
   - Click "Test API" to verify the connection

## Step 4: Test the API

1. **Go to the Chat page**:
   - Navigate to `/chat` in your application
   - Try asking a simple question like "Hello, how are you?"

2. **Expected behavior**:
   - You should receive a response from AgriBot
   - The response should be in your selected language
   - The API status should show "API Working Perfectly"

## Troubleshooting

### Common Issues

1. **"API key not configured" error**:
   - Make sure your `.env` file is in the project root
   - Verify the variable name is exactly `VITE_GEMINI_API_KEY`
   - Restart your development server after adding the key

2. **"Authentication failed" error**:
   - Check that your API key is correct
   - Ensure there are no extra spaces or characters
   - Verify the API key is active in Google AI Studio

3. **"Rate limit exceeded" error**:
   - You've exceeded the free tier limits
   - Wait a few minutes before trying again
   - Consider upgrading to a paid plan for higher limits

4. **"Network error" message**:
   - Check your internet connection
   - Verify firewall settings aren't blocking the requests
   - Try again after a few minutes

### API Key Validation

The application automatically validates your API key:
- ✅ **Valid**: Key is properly configured and working
- ⚠️ **Invalid**: Key format is incorrect or missing
- ❌ **Error**: Key is valid but there's a connection issue

## API Usage and Limits

### Free Tier Limits
- **Requests per minute**: 60 requests
- **Requests per day**: 1,500 requests
- **Tokens per minute**: 32,000 tokens

### Best Practices
1. **Implement caching** for frequently asked questions
2. **Use rate limiting** to avoid exceeding quotas
3. **Monitor usage** through Google AI Studio dashboard
4. **Handle errors gracefully** with proper user feedback

## Security Considerations

1. **Never commit your API key** to version control
2. **Use environment variables** for all sensitive data
3. **Rotate your API key** regularly
4. **Monitor usage** for any suspicious activity
5. **Set up billing alerts** if using paid tiers

## Production Deployment

For production deployment:

1. **Set environment variables** in your hosting platform:
   - Vercel: Add in Project Settings → Environment Variables
   - Netlify: Add in Site Settings → Environment Variables
   - Heroku: Use `heroku config:set VITE_GEMINI_API_KEY=your_key`

2. **Use a production API key**:
   - Create a separate API key for production
   - Restrict the key to specific domains if possible

3. **Monitor and log**:
   - Set up monitoring for API usage
   - Log errors for debugging
   - Track response times and success rates

## Support

If you encounter issues:

1. **Check the console** for error messages
2. **Verify your setup** using this guide
3. **Test with a simple query** first
4. **Check Google AI Studio** for service status
5. **Review the Gemini API documentation**

## Additional Resources

- [Gemini API Documentation](https://ai.google.dev/docs)
- [Google AI Studio](https://makersuite.google.com/)
- [Rate Limits and Quotas](https://ai.google.dev/docs/quotas)
- [Best Practices Guide](https://ai.google.dev/docs/best_practices)

---

**Note**: Keep your API key secure and never share it publicly. The free tier should be sufficient for development and testing, but consider upgrading for production use with high traffic.
